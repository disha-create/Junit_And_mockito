package com.citiuctech.model;

import com.citiustech.ExceptionHandling.AccointIdNotFoundException;
import com.citiustech.ExceptionHandling.InsufficientFundException;
import com.citiustech.ExceptionHandling.NegativeAmountException;

public class SavingsAccount extends Account {

	private double min_Balanace= 100;
	
	public SavingsAccount(int id, double balance){
		super(id,balance);
	}

	public void setMin_Balanace(double min_Balanace) {
		balance = min_Balanace;
	}
	
	public boolean withdraw(int id, double balance, double amount){
		accountDetailsMap();
		
		if (accountDetails.containsKey(id)){
			if(amount  > 0){
				if(balance - amount > min_Balanace){
					balance = balance - amount;
					return true;
				}
				else{
					throw new InsufficientFundException();
				}
			}
			else{
				throw new NegativeAmountException();
			}
		}
		else{
			throw new AccointIdNotFoundException();
		}
	}
	
	
	public boolean deposite(int id, int amount){
		accountDetailsMap();
		
		if(accountDetails.containsKey(id)){
			if(amount > 0){
				balance += amount;
				return true;
			}
			else {
				throw new NegativeAmountException();
			}
		}
		else{
			throw new AccointIdNotFoundException();
		}
	}
	
	
}

package com.citiuctech.model;

import java.util.HashMap;
import java.util.Map;

public class Account {
	
	private int accountId;
	protected double balance;
	
	static Map<Integer, Double> accountDetails = new HashMap<Integer, Double>();
	
	public void accountDetailsMap(){
		accountDetails.put(2011,1000.00);
		accountDetails.put(2012,2000.00);
		accountDetails.put(2013,3000.00);
		accountDetails.put(2014,4000.00);
		accountDetails.put(2015,5000.00);
		
	}
	
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(int accountId, double balance) {
		super();
		this.accountId = accountId;
		this.balance = balance;
	}
	public int getAccountId() {
		return accountId;
	}
	
	public double getBalance() {
		return balance;
	}
	
	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", balance=" + balance + "]";
	}
	
	
	

}

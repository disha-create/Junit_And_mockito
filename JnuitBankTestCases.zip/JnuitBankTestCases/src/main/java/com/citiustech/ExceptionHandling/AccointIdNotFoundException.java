package com.citiustech.ExceptionHandling;

public class AccointIdNotFoundException extends RuntimeException{

}

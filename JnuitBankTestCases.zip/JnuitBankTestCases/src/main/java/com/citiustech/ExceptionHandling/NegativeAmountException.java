package com.citiustech.ExceptionHandling;

public class NegativeAmountException extends RuntimeException{

}

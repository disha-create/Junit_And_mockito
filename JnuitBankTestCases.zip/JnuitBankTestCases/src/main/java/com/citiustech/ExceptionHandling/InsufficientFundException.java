package com.citiustech.ExceptionHandling;

public class InsufficientFundException extends RuntimeException{

}

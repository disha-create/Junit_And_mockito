package com.citiustech.test;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import com.citiuctech.model.SavingsAccount;
import com.citiustech.ExceptionHandling.InsufficientFundException;
import com.citiustech.ExceptionHandling.NegativeAmountException;


public class SavingsAccountTest {

	@Parameter(0)
	public int id;
	
	@Parameter(1)
	public double balance;
	
	@Parameter(2)
	public boolean result;
	
	@Parameters
	public static List userInputData(){
		return Arrays.asList(new Object[][]{{2011,100000,true},
			{2012,20000,true},{2013,30000,true},{2014,40000,true},{2015,100000,true}});	
		
	}
	
	SavingsAccount savingsAccount;
	
	@Before
	public void creatingObjectOfSavingAccountClass(){
		savingsAccount = new SavingsAccount(id, balance);
	}
	
	 @Test
	 public void withdrawMoneyIfAccountIdIsCorrectAndExist(){
	    assertEquals(result, savingsAccount.withdraw(id,balance,100));
	 }
	
	@Test(expected=AccountNotFoundException.class)
	public void withdrawShouldFailIfAccountIdIsWontExist(){
		assertEquals(result, savingsAccount.withdraw(id, balance, 100));
	}
	
	@Test(expected=InsufficientFundException.class)
	public void ifbalanaceLessThanMinimumBalanaceThenWithdrawShouldFail(){
		assertEquals(result, savingsAccount.withdraw(id,balance, 50000));
	}
	
	@Test
    public void withdrawShouldFailIfAmmountisNegative(){
    	assertEquals(result,savingsAccount.withdraw(id, balance,100));
    }
	
	@Test(expected=NegativeAmountException.class)
    public void withdrawShouldFailIfAmmountisNegativeAndThrowsException(){
    	assertEquals(result,savingsAccount.withdraw(id, balance,100));
    }
	
	@Test(expected=AccountNotFoundException.class)
    public void moneyShouldNotDepositeIfAccountIdNotExistAndShouldThrowException(){
    	assertEquals(result, savingsAccount.deposite(id,1000));
    }
	
	@Test
    public void depositeShouldFailIfAmountIsNegative(){
    	assertEquals(result, savingsAccount.deposite(id, 100));
    }
}

package com.citiustech.algorithm;

public class Addition {

	public static int add(int first,int second){
		return first+second;
	}
}

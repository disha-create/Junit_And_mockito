package algorithm;

import bank.AccountIdNotExist;
import bank.NegativeAmountException;

public class CurrentAccount extends Account{

	public CurrentAccount(int id, double balance){
		super(id,balance);
	}

	public boolean withdraw(int id, double balance, int amount) {
		accountDetailsMap();
		if(accountDetails.containsKey(id)){
			if(amount>0){
				balance -= amount;
				return true;
			}
			else{
				throw new NegativeAmountException();
			}
		}
		else{
			throw new AccountIdNotExist();
		}
	}

	public boolean deposite(int id, int amount) {
		accountDetailsMap();
		if(accountDetails.containsKey(id)){
			if(amount>0){
				if(balance<0)amount *= 0.9;
						balance += amount;
//						System.out.printf("Amount:"+amount);
//						System.out.printf("Balance:"+balance);
						
						return true;
			}
			else{
				throw new NegativeAmountException();
			}
		}
		else {
			throw new AccountIdNotExist();
		}
	}
}

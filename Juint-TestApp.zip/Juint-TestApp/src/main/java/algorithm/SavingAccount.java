package algorithm;

import java.util.HashMap;
import java.util.Map;

import bank.AccountIdNotExist;
import bank.InsufficientBalanceException;
import bank.NegativeAmountException;

public class SavingAccount extends Account{
	
	public double Minimum_balance = 1000;

	 
	public SavingAccount(int id, double balance) {
		super(id,balance);
	}

	public void setMinimumBalance(){
		balance = Minimum_balance ;
	}
	
	public boolean withdraw(int id, double balance, double amount){
		accountDetailsMap();
		if (accountDetails.containsKey(id)){
//			System.out.println(id);
			if (amount > 0){
				
					if (balance - amount < Minimum_balance){
						throw new InsufficientBalanceException();
					}
					else{
						balance -= amount;
						return true;
					}
			}
			else {
	//			System.out.println("Amount should not be in negative.");
				throw new NegativeAmountException();
			}
		}
		else{
			throw new AccountIdNotExist();
		}
	
	}

	public boolean deposite(int id, int amount) {
		accountDetailsMap();
		if (accountDetails.containsKey(id)){
			if (amount > 0){
				balance += amount;
				return true;
			}
			else{
				throw new NegativeAmountException();
			}
			
		}
		else{
			throw new AccountIdNotExist();
		}
	}
	

}

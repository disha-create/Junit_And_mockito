package algorithm;

import java.lang.Thread.State;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Account {
	
	private int AccountId;
	protected double balance;
	
	static Map<Integer, Double> accountDetails = new HashMap<Integer, Double>();
	 
	public void accountDetailsMap(){
		
		 accountDetails.put(101,1000.0);
		 accountDetails.put(102,4000.0);
		 accountDetails.put(103,5000.0);
		 accountDetails.put(104,10000.0);
		 
//		 for (Map.Entry<Integer, Double> entry : accountDetails.entrySet());

	}

	public Account() {
		
	}
	
	public Account(int accountId, double balance) {
		AccountId = accountId;
		this.balance = balance;
	}
	
	public int getAccountId() {
		return AccountId;
	}


	public double getBalance() {
		return balance;
	}


	@Override
	public String toString() {
		return "Account [AccountId=" + AccountId + ", balance=" + balance + "]";
	}

}

package bank;

public class InsufficientBalanceException extends RuntimeException{
	
}

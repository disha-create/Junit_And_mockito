package bank;

public class AccountIdNotExist extends RuntimeException{

}

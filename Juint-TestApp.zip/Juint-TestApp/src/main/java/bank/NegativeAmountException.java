package bank;

public class NegativeAmountException  extends RuntimeException{

}

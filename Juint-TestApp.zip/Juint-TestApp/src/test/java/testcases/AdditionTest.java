package testcases;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.citiustech.algorithm.Addition;



public class AdditionTest {

	@Test
	public void addTwoPositiveNumbers(){
		assertEquals(50, Addition.add(25,25));
	}
	
	@Test
	public void addonePositiveAndOneNegative(){
		assertEquals(25, Addition.add(-25,25));
	}
	
	@Test
	public void addTwo(){
		assertEquals(25, Addition.add(-25,25));
	}
	
	
}

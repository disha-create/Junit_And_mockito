package testcases;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import algorithm.CurrentAccount;
import bank.AccountIdNotExist;
import bank.NegativeAmountException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


@RunWith(Parameterized.class)
public class CurrentAccountTest {



	@Parameter(0)
	public int id;
	
	@Parameter(1)
	public double balance;
	
	@Parameter(2)
	public boolean result;
	
	@Parameters
	public static List inputData(){
		return Arrays.asList(new Object[][]{{101,2000,true},
			{102,4000,true},{103,5000,true},{104,10000,true}});
	}
	
	CurrentAccount c;
	
	@Before
	public void creatingObjectOfCurrectAccountClass(){
		c = new CurrentAccount(id, balance);
	}
	
	
	 @Test(expected=AccountIdNotExist.class)
	 public void moneyShouldNotWithdrawIfAccountIdNotExistAndShouldThrowException(){
	    assertEquals(result, c.withdraw(id, balance,100));
	 }
	 
	 @Test
	 public void withdrawMoneyIfAccountIdIsCorrectAndExist(){
	    assertEquals(result, c.withdraw(id, balance,100));
	 }
	
	  @Test(expected=NegativeAmountException.class)
	  public void ifWithdrawAmountInNegativeThenShouldThrowNegativeAmountException(){
	    assertEquals(result, c.withdraw(id,balance, -100));
	 }
	  
	  @Test
	  public void ifWithdrawAmountIsNotInNegativeThenShouldReturnTrue(){
	    assertEquals(result, c.withdraw(id,balance, 100));
	 }
	  
	 @Test
	 public void depositeMoneyIfAccountIdIsCorrectAndExist(){
	    assertEquals(result, c.deposite(id,1000));
	 }
	
	 @Test(expected=AccountIdNotExist.class)
	 public void moneyShouldNotDepositeIfAccountIdNotExistAndShouldThrowException(){
	   assertEquals(result, c.deposite(id,1000));
	 }
	 
	 @Test(expected=NegativeAmountException.class)
	 public void ifDepositeAmountInNegativeThenShouldThrowNegativeAmountException(){
	    assertEquals(result, c.deposite(id, -100));
	 }
	 
	 @Test
	 public void ifDepositeAmountNotInNegativeThenShouldThrowNegativeAmountException(){
	    assertEquals(result, c.deposite(id, 100));
	 }
	 
	@Test
	 public void depositeMethodShouldApplyPenaltyChargesIfBalanceIsLessThanZero(){
		 assertEquals(result,c.deposite(id, 1000));
	 } 
}

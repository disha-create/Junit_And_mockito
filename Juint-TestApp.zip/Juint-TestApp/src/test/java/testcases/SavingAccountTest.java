package testcases;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

import algorithm.SavingAccount;
import bank.AccountIdNotExist;
import bank.InsufficientBalanceException;
import bank.NegativeAmountException;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;


@RunWith(Parameterized.class)
public class SavingAccountTest {

	@Parameter(0)
	public int id;
	
	@Parameter(1)
	public double balance;
	
	@Parameter(2)
	public boolean result;
	

	
	@Parameters
	public static List inputData(){
		return Arrays.asList(new Object[][]{{101,2000,true},
			{102,4000,true},{103,5000,true},{104,10000,true}});
	}
	
	SavingAccount s;
	
    @Before
	public void creatingObjectOfSavingAccountClass(){
		s = new SavingAccount(id,balance);
	}
	

    @Test
    public void withdrawMoneyIfAccountIdIsCorrectAndExist(){
    	assertEquals(result, s.withdraw(id,balance,100));
    }
    
    @Test(expected=AccountIdNotExist.class)
    public void moneyShouldNotWithdrawIfAccountIdNotExistAndShouldThrowException(){
    	assertEquals(result, s.withdraw(id, balance,100));
    }

	@Test(expected=InsufficientBalanceException.class)
	public void balanceIsLessThanMinimalBalanceThenShouldThrowInsufficientBalanceException(){
//		System.out.println(s.withdraw(balance, 500));
		assertEquals(result, s.withdraw(id,balance, 50000));
//		assertTrue(s.withdraw(balance, 1000));
	}
    
	@Test
	public void balanceIsNotLessThanMinimalBalanceThenShouldWithdrawMoneyAndReturnTrue(){
//		System.out.println(s.withdraw(balance, 500));
		assertEquals(result, s.withdraw(id,balance, 100));
//		assertTrue(s.withdraw(balance, 1000));
		
	}

    @Test(expected=NegativeAmountException.class)
    public void ifWithdrawAmountIsInNegativeThenShouldThrowNegativeAmountException(){
//    	assertFalse(s.withdraw(balance, -100));
    	assertEquals(result, s.withdraw(id,balance,-100));
    }
    
    @Test
    public void ifWithdrawAmountNotInNegativeThenShouldThrowNegativeAmountException(){
//    	assertFalse(s.withdraw(balance, -100));
    	assertEquals(result,s.withdraw(id, balance,100));
    }
    
    @Test
    public void depositeMoneyIfAccountIdIsCorrectAndExist(){
    	assertEquals(result, s.deposite(id,1000));
    }
    
    @Test(expected=AccountIdNotExist.class)
    public void moneyShouldNotDepositeIfAccountIdNotExistAndShouldThrowException(){
    	assertEquals(result, s.deposite(id,1000));
    }

    @Test(expected=NegativeAmountException.class)
    public void ifDepositeAmountIsInNegativeThenShouldThrowNegativeAmountException(){
//    	assertFalse(s.withdraw(balance, -100));
    	assertEquals(result, s.deposite(id, -100));
    }
    
    @Test
    public void ifDepositeAmountIsNotInNegativeThenShouldReturnTrue(){
//    	assertFalse(s.withdraw(balance, -100));
    	assertEquals(result, s.deposite(id, 100));
    }
 

}

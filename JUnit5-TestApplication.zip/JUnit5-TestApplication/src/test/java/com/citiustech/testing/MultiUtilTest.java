package com.citiustech.testing;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.citiustech.algorithm.multiUtil;



public class MultiUtilTest {
	multiUtil mutil =  null;
	
	@BeforeEach
	public void setUp(){
		mutil = new multiUtil();
	}
	
	@Test
	@Tag("Sanity")
	public void multiplicationShouldMultiplyTwoNumbers(){
	  
		assertEquals(20, mutil.multiplication(4,5));
	}
	
	@Test
	@Tag("Sanity")
	public void divisionShouldDivideTwoNumbers(){
		assertEquals(20,mutil.multiplication(4,5));
	}
	
	@AfterEach
	public void tearDown(){
		mutil = null;
	}
	


}

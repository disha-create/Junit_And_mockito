package com.citiustech.testing;

import static org.junit.Assert.assertEquals;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.citiustech.algorithm.Calculator;

public class CalculatorTest {
	
	Calculator calc = null;
	
	@BeforeEach
	public void setUp(){
		calc = new Calculator();
	}
	
	
	@Test
	@Tag("Smoke")
	public void additionShouldAddTwoNumbers(){
	   assertEquals(30, calc.addition(10, 20));  
	}
	
	@Test
	@Tag("Smoke")
	public void substractionShouldAddTwoNumbers(){
	   assertEquals(30, calc.substraction(50,20));  
	}
	
	@AfterEach
	public void tearDown(){
		calc = null;
	}

}

package com.citiustech.testing;

import org.junit.platform.suite.api.SelectClasses;

@SelectClasses({"Smoke","Sanity"})
public class AllClasses {

}

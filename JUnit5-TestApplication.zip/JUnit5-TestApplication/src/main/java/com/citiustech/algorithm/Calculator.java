package com.citiustech.algorithm;

public class Calculator {
	
	
	public int addition(int first,int second){
		return first + second;
	}
	
	public int substraction(int first,int second){
		return first - second;
	}

}

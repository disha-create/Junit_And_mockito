package com.citiustech.algorithm;

public class multiUtil {
	
	public int multiplication(int first,int second){
		return first - second;
	}

	public int division(int first,int second){
		return first - second;
	}


}

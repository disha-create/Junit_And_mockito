$(document).ready(() => {
    $('#header').load('header.html');

    if(window.localStorage.getItem('CustomerID') == null){
        window.location.href = "./login.html";
    }

    $.get("http://localhost:8080/invoices/get/customer/"+window.localStorage.getItem('CustomerID') , data=>{
        var container = ``;
        var total = 0;
        for(let i=0 ; i< data.length ; i++){
            total+=data[i].amt;
        //     container += `<div class="card grid-item col-md-6">
        //     <div class="card-body">
        //         <h5 class="card-title">Order No :- ${data[i].ord_no}</h5>
        //         <p class="card-text">Order Date :- ${data[i].ord_date}</p>
        //         <p class="card-text">Cust id :- ${data[i].cust_id}</p>
        //         <h5 class="card-title">Product No :- ${data[i].pno}</h5>
        //         <p class="card-text">Quantity :- ${data[i].qty}</p>
        //         <p class="card-text">Amount :- ${data[i].amt}</p>
        //     </div>
        //  </div>`;
        $("#pp").append(`<tr>
        <td>${data[i].ord_no}</td>
        <td>${data[i].ord_date}</td>
        <td>${data[i].pno}</td>
        <td>${data[i].qty}</td>
        <td>${data[i].amt}</td>
      </tr>`)
        }
        console.log(total);
        $('#content').html(container);
        $('#total').html("<h6><strong>Total Amount Spend: "+total+"</strong></h6>");
    });
})

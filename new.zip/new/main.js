$(document).ready(() => {
    $('#header').load('header.html');
    $.get("http://localhost:8080/products/all", data => {

        var container = ``;

        for (let i = 0; i < data.length; i++) {
            container += `
            <div class="col-lg-4 col-md-6 d-flex align-items-stretch">
            <div class="course-item">
            <img src="cart1.png" class="img-fluid" alt="...">
            <div class="course-content">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4>Product Id:- ${data[i].pno}</h4>
                    <p class="price">₹${data[i].price}</p>
                </div>
                <h6><a href="course-details.html">Available Stock:-${data[i].stock}</a></h6>
                <div class="trainer d-flex justify-content-between align-items-center">
                <a class="btn btn-primary" id="btt" href="./order.html?pno=${data[i].pno}">Order</a>
                </div>
            </div>
            </div>
            </div>`;
        }
        $('#tt').html(container);
    });

    $('#btt').click(()=>{
        // window.localStorage.setItem;
        console.log("helooooooo");
        window.localStorage.setItem("ProductID", data[i].pno);
    })
})
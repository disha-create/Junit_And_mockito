$(document).ready(() => {
    $('#header').load('header.html');

    if(window.localStorage.getItem('CustomerID') == null){
        window.location.href = "./login.html";
    }

    $('#placeorder').click(()=>{
        console.log("Hey");
        console.log(window.location.href);

        var url = window.location.href;
        var file = url.substring(url.lastIndexOf('?')+5);

        // var pno = $('#pno').val();
        var quantity = $('#quantity').val();

        if(quantity=== ''){
            alert("Enter Quantity");
        }else{
            // var data = {
            //     pno:file,
            //     qty:quantity,
            //     cust_id:window.localStorage.getItem('CustomerID')
            // }

            let new_req = {
                customers: {
                  custid:window.localStorage.getItem('CustomerID')
                },
                products: {
                  pno: file
                },
                qty: quantity
              }
            // console.log(data);
            // var dataObject = JSON.stringify(data);
            // console.log(dataObject);
            // console.log(window.location.href);

            $.ajax({
                type: "POST",
                url: 'http://localhost:8080/orders/place',
                data: JSON.stringify(new_req),
                dataType: 'application/json',
                contentType:'application/json',
                success : function(data) {
                    console.log(data);
                }
              });
        }
    });
})
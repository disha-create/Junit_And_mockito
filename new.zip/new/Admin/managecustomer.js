$(document).ready(() => {
    $('#header').load('header.html');

    if(window.localStorage.getItem('AdminID') == null){
        window.location.href = "./login.html";
    }

    var url = window.location.href;
    var file = url.substring(url.lastIndexOf('?') + 8);
    $.get("http://localhost:8080/customers/get/" + file, data => {

        var ctr = `
        <div class="form-group mt-3">
        <input type="text" class="form-control" name="customerid" id="customerid"
            placeholder="Customer Id" value="${data.custid}" required>
    </div>
    <div class="form-group mt-3">
        <input type="password" class="form-control" name="password" id="password"
            placeholder="password" value="${data.pwd}" required>
    </div>
    <div class="form-group mt-3">
        <input type="email" class="form-control" name="email" id="email"
            placeholder="Email" value="${data.email}" required>
    </div>
    <div class="form-group mt-3">
        <input type="number" class="form-control" name="credit" id="credit"
            placeholder="Credit" value="${data.credit}" required>
    </div>`;

        $('#tt').html(ctr);
    });

    $('#update').click(() => {
        
        var customerid = $('#customerid').val();
        var password = $('#password').val();
        var email = $('#email').val();
        var credit = $('#credit').val();

        var data = {
            custid: customerid,
            pwd: password,
            email: email,
            credit: credit
    }

    $.ajax({
        type: "PUT",
        url: 'http://localhost:8080/customers/update/'+file,
        data: JSON.stringify(data),
        dataType: 'application/json',
        contentType:'application/json',
        success: function (data) {
            console.log(data);
          }
      });
    })
})
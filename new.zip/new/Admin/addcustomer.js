$(document).ready(() => {
    $('#header').load('header.html');

    if(window.localStorage.getItem('AdminID') == null){
        window.location.href = "./login.html";
    }

    $('#submit').click(()=>{

        var customerid = $('#customerid').val();
        var password = $('#password').val();
        var email = $('#email').val();
        var credit = $('#credit').val();

        // console.log(price);

        var data = {
            custid: customerid,
            pwd: password,
            email: email,
            credit: credit
    }

        $.ajax({
            type: "POST",
            url: 'http://localhost:8080/customers/save',
            data: JSON.stringify(data),
            dataType: 'application/json',
            contentType:'application/json',
            success: function (msg) {
                console.log("Data Inserted Successfully...");
              }
          });
    });

})
$(document).ready(() => {
    $('#header').load('header.html');

    if(window.localStorage.getItem('AdminID') == null){
        window.location.href = "./login.html";
    }

    var url = window.location.href;
    var file = url.substring(url.lastIndexOf('?') + 5);
    $.get("http://localhost:8080/products/get/" + file, data => {

        var container = ``;
        var ctr = `
        <div class="form-group mt-3">
            <input type="text" class="form-control" name="productno" id="productno"
            placeholder="Product No" value="${data.pno}" required>
        </div>
        <div class="form-group mt-3">
            <input type="number" class="form-control" name="price" id="price"
            placeholder="Price" value="${data.price}" required>
        </div>
        <div class="form-group mt-3">
            <input type="number" class="form-control" name="stock" id="stock"
            placeholder="Stock" value="${data.stock}" required>
        </div>`;

        $('#tt').html(ctr);
    });

    $('#update').click(() => {
        
        var productno = $('#productno').val();
        var price = $('#price').val();
        var stock = $('#stock').val();

        var data1 = {
            pno: productno,
            price: price,
            stock: stock
    }

    $.ajax({
        type: "PUT",
        url: 'http://localhost:8080/products/update/'+file,
        data: JSON.stringify(data1),
        dataType: 'application/json',
        contentType:'application/json',
        success: function (data) {
            console.log(data);
          }
      });
    })
})
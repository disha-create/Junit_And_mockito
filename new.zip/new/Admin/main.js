$(document).ready(() => {
    $('#header').load('header.html');
    // if(window.localStorage.getItem('AdminID') == null){
    //     window.location.href = "./login.html";
    // }
    $.get("http://localhost:8080/products/all", data => {
        var container = ``;
        for (let i = 0; i < data.length; i++) {
            container += `
            <div class="col-xl-4 d-flex align-items-stretch">
                <div class="icon-box mt-4 mt-xl-0">
                    <i class="bx bx-receipt"></i>
                    <h4>Product No :- ${data[i].pno}</h4>
                    <p>Price :- ${data[i].price}</p>
                    <p>Available Stock :- ${data[i].stock}</p>
                    <a class="btn btn-primary" href="./manageproduct.html?pno=${data[i].pno}">Manage</a>
                </div>
            </div>`;
        }
        $('#tt').html(container);
    });

    $.get("http://localhost:8080/customers/all", data => {
        var container1 = ``;
        for (let i = 0; i < data.length; i++) {
            container1 += `
            <div class="col-lg-3 col-md-4 mt-4">
                <div class="icon-box">
                    <i class="ri-fingerprint-line" style="color: #29cc61;"></i>
                    <h3>Customer:- <a href="./managecustomer.html?custid=${data[i].custid}">${data[i].custid}</a></h3>
                </div>
            </div>`;
        }
        $('#cust').html(container1);
    });
})
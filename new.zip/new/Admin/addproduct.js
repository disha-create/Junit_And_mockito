$(document).ready(() => {
    $('#header').load('header.html');

    if(window.localStorage.getItem('AdminID') == null){
        window.location.href = "./login.html";
    }

    $('#submit').click(()=>{

        var productno = $('#productno').val();
        var price = $('#price').val();
        var stock = $('#stock').val();

        // console.log(price);

        var data = {
            pno: productno,
            price: price,
            stock: stock
    }

        $.ajax({
            type: "POST",
            url: 'http://localhost:8080/products/save',
            data: JSON.stringify(data),
            dataType: 'application/json',
            contentType:'application/json',
            success: function (msg) {
                console.log("Data Inserted Successfully...");
              }
          });
    });

})
$(document).ready(() => {

    if(window.localStorage.getItem('CustomerID') == null){
        window.location.href = "./login.html";
    }

    $.get("http://localhost:8080/invoices/get/customer/" + window.localStorage.getItem('CustomerID'), data => {
        var container = ``;
        var total = 0;
        const date = new Date();
        var c = `${window.localStorage.getItem('CustomerID')}`;
        $('#custid').append(`<p>${c}</p>`);
        for (let i = 0; i < data.length; i++) {
            total += data[i].amt;
            $("#pp").append(`<tr>
            <td>${data[i].ord_no}</td>
            <td class="text-center">${data[i].ord_date}</td>
            <td class="text-center">${data[i].pno}</td>
            <td class="text-center">${data[i].qty}</td>
            <td class="text-center">${data[i].amt}</td>
            </tr>`)
        }

        $("#ff").append(`
        <tr>
            <th></th>
            <th></th>
            <th colspan="2" class="text-right">Total:</th>
            <th class="text-center">₹${total}</th>
        </tr>`);

        $("#date").append(` ${date}`);
    });
});
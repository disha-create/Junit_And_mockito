package com.example.SalesApplication.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Customers {
	private String custid;
	private String pwd;
	private String email;
	private double credit;
	
	public Customers(){
		
	}

	public Customers(String custid, String pwd, String email, double credit) {
		this.custid = custid;
		this.pwd = pwd;
		this.email = email;
		this.credit = credit;
	}

	@Id
	@Column(name="cust_id")
	public String getCustid() {
		return custid;
	}

	public void setCustid(String custid) {
		this.custid = custid;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public double getCredit() {
		return credit;
	}

	public void setCredit(double credit) {
		this.credit = credit;
	}

	@Override
	public String toString() {
		return "Customers [cust_id=" + custid + ", pwd=" + pwd + ", email=" + email + ", credit=" + credit + "]";
	}
	
}

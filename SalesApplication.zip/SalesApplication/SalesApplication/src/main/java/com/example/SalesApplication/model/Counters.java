package com.example.SalesApplication.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Counters {
	private String ctrname;
	private int curval;
	
	public Counters(){
		
	}

	public Counters(String ctrname, int curval) {
		this.ctrname = ctrname;
		this.curval = curval;
	}

	@Id
	@Column(name="ctr_name")
	public String getCtrname() {
		return ctrname;
	}

	public void setCtrname(String ctrname) {
		this.ctrname = ctrname;
	}

	@Column(name="cur_val")
	public int getCurval() {
		return curval;
	}

	public void setCurval(int curval) {
		this.curval = curval;
	}
	
}

package com.example.SalesApplication.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.SalesApplication.model.Counters;

@Repository
public interface CounterRepository extends CrudRepository<Counters, Integer> {
	Counters findByCtrname(String name);
}

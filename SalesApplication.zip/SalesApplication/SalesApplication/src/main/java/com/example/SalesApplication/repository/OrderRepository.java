package com.example.SalesApplication.repository;

import java.util.Collection;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.SalesApplication.model.Customers;
import com.example.SalesApplication.model.Orders;
import com.example.SalesApplication.model.Products;

@Repository
public interface OrderRepository extends CrudRepository<Orders, Integer> {
	Collection<Orders> findByCustomers(Customers c);
	Collection<Orders> findByProducts(Products p);
}

package com.example.SalesApplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.example.SalesApplication.model.Customers;
import com.example.SalesApplication.service.CustomerService;

@RestController
@EnableWebMvc
@RequestMapping("customers")
@CrossOrigin(origins="http://127.0.0.1:5501")
public class CustomerController {
	
	@Autowired
	private CustomerService customerService;
	
	@PostMapping(value="save", consumes="application/json")
	public void saveCustomer(@RequestBody Customers customers){
		customerService.saveCustomer(customers);
	}
	
	@GetMapping(value="all", produces="application/json")
	public List<Customers> getAllCustomers(){
		return customerService.getAllCustomers();
	}
	
	@GetMapping(value="get/{id}", produces="application/json")
	public Customers getCustomerById(@PathVariable String id){
		return customerService.getCustomerById(id);
	}
	
	@DeleteMapping(value="delete/{id}", consumes="application/json")
	public void deleteCustomer(@PathVariable String id){
		customerService.deleteCustomer(id);
	}
}

package com.example.SalesApplication.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SalesApplication.model.Counters;
import com.example.SalesApplication.repository.CounterRepository;

@Service
public class CounterService {
	
	@Autowired
	private CounterRepository counterRepository;
	
	public Counters getCounter(String name){
		Counters counters = counterRepository.findByCtrname(name);
		return counters;
	}
	
	public Counters getOrderCounter(){
		Counters counters = counterRepository.findByCtrname("orders");
		return counters;
	}

	public Counters getProductCounter(){
		Counters counters = counterRepository.findByCtrname("products");
		return counters;
	}

	
	public int getNextValueofOrders(Counters counters){
//		return counter.getVal() + 1001;
		return counters.getCurval()+1001;
	}
	
	public int getNextValueofProducts(Counters counters){
		return counters.getCurval() + 301;
	}
	
	public void incrementCounter(Counters counters){
		counters.setCurval(counters.getCurval() + 1);
		counterRepository.save(counters);
	}
}

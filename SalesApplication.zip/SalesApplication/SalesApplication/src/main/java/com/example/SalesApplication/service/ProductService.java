package com.example.SalesApplication.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SalesApplication.model.Products;
import com.example.SalesApplication.repository.ProductRepository;

@Service
public class ProductService {

	@Autowired
	private ProductRepository productRepository;
	
	@Transactional
	public void saveProduct(Products products){
		productRepository.save(products);
	}
	
	public List<Products> getAllPeoducts(){
		List<Products> productlist = new ArrayList<Products>();
		productRepository.findAll().forEach(productlist::add);
		return productlist;
	}
	
	public Products getProductById(int pid){
		Optional<Products> ptd = productRepository.findById(pid);
		Products ptds = ptd.get();
		return ptds;
	}
	
	@Transactional
	public void updateProduct(int id, Products products){
		productRepository.save(products);
	}
	
	@Transactional
	public void deleteProduct(int id){
		productRepository.deleteById(id);
	}
	
}

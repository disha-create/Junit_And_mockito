package com.example.SalesApplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.example.SalesApplication.model.Products;
import com.example.SalesApplication.service.ProductService;

@RestController
@EnableWebMvc
@RequestMapping("products")
@CrossOrigin(origins="http://127.0.0.1:5501")
public class ProductController {

	@Autowired
	private ProductService productService;
	
	
	@PostMapping(value="save", consumes="application/json")
	public void saveProduct(@RequestBody Products products){
		System.out.println(products);
		productService.saveProduct(products);
	}
	
	@GetMapping(value="all", produces="application/json")
	public List<Products> getAllPeoducts(){
		return productService.getAllPeoducts();
	}
	
	@GetMapping(value="get/{id}", produces="application/json")
	public Products getProductById(@PathVariable int id){
		return productService.getProductById(id);
	}
	
	@DeleteMapping(value="delete/{id}", consumes="application/json")
	public void deleteProduct(@PathVariable int id){
		productService.deleteProduct(id);
	}
}

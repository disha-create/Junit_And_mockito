package com.example.SalesApplication.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.example.SalesApplication.model.Invoices;
import com.example.SalesApplication.service.InvoiceService;

@RestController
@EnableWebMvc
@RequestMapping("invoices")
@CrossOrigin(origins="http://127.0.0.1:5501")
public class InvoiceController {

	@Autowired
	private InvoiceService invoiceService;
	
	@GetMapping(value="all", produces="application/json")
	public Collection<Invoices> getAllInvoices(){
		return invoiceService.getAllInvoices();
	}
	
	@GetMapping(value="get/{id}", produces="application/json")
	public Invoices getInvoiceById(@PathVariable int id){
		return invoiceService.getInvoiceById(id);
	}
}

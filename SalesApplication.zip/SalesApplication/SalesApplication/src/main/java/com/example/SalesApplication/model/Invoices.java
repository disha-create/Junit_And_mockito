package com.example.SalesApplication.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Table;

public class Invoices {
	private int ord_no;
	private LocalDate ord_date;
	private String cust_id;
	private int pno;
	private int qty;
	private double amt;
	
	public Invoices(){
		
	}

	public Invoices(int ord_no, LocalDate ord_date, String cust_id, int pno, int qty, double amt) {
		this.ord_no = ord_no;
		this.ord_date = ord_date;
		this.cust_id = cust_id;
		this.pno = pno;
		this.qty = qty;
		this.amt = amt;
	}

	public double getAmt() {
		return amt;
	}

	public void setAmt(double amt) {
		this.amt = amt;
	}

	public int getOrd_no() {
		return ord_no;
	}

	public void setOrd_no(int ord_no) {
		this.ord_no = ord_no;
	}

	public LocalDate getOrd_date() {
		return ord_date;
	}

	public void setOrd_date(LocalDate ord_date) {
		this.ord_date = ord_date;
	}

	public String getCust_id() {
		return cust_id;
	}

	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}

	public int getPno() {
		return pno;
	}

	public void setPno(int pno) {
		this.pno = pno;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	@Override
	public String toString() {
		return "Invoices [ord_no=" + ord_no + ", ord_date=" + ord_date + ", cust_id=" + cust_id + ", pno=" + pno
				+ ", qty=" + qty + ", amt=" + amt + "]";
	}
	
}

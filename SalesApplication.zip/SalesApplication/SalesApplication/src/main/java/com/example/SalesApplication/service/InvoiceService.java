package com.example.SalesApplication.service;

import java.util.Collection;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SalesApplication.model.Customers;
import com.example.SalesApplication.model.Invoices;
import com.example.SalesApplication.model.Products;
import com.example.SalesApplication.repository.InvoiceDAO;

@Service
public class InvoiceService {
	
	@Autowired
	private InvoiceDAO invoiceDAO;
	
	public Collection<Invoices> getAllInvoices(){
		return invoiceDAO.getAllInvoices();
	}
	
	public Invoices getInvoiceById(int id){
		return invoiceDAO.getInvoiceById(id);
	}
	
}

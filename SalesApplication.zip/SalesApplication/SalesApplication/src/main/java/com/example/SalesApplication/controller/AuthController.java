package com.example.SalesApplication.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.example.SalesApplication.Exception.CustomerNotFoundException;
import com.example.SalesApplication.model.Customers;
import com.example.SalesApplication.service.AuthService;

@RestController
@EnableWebMvc
@RequestMapping("auth")
@CrossOrigin(origins="http://127.0.0.1:5501")
public class AuthController {
	
	@Autowired
	private AuthService authService;
	
	@PostMapping(value="login", consumes="application/json")
    private ResponseEntity<?> login(@RequestBody Customers c) throws CustomerNotFoundException{
		authService.Login(c);;
        Map<String, String> info = new HashMap<>();
        info.put("CustomerId", c.getCustid());
        return new ResponseEntity<>(info , HttpStatus.OK);
    }
    
    @GetMapping(value="login",produces="application/json")
    private String loginT(){
        return "hello";
    }
}

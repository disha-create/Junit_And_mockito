package com.example.SalesApplication.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SalesApplication.model.Counters;
import com.example.SalesApplication.model.Customers;
import com.example.SalesApplication.model.Orders;
import com.example.SalesApplication.model.Products;
import com.example.SalesApplication.repository.CounterRepository;
import com.example.SalesApplication.repository.CustomerRepository;
import com.example.SalesApplication.repository.OrderRepository;
import com.example.SalesApplication.repository.ProductRepository;

@Service
public class OrderService {
	
	@Autowired
	private OrderRepository orderRepository;
	
	@Autowired
	private CounterService counterService;
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	//get all orders
	public List<Orders> getAllOrders(){
		List<Orders> orderlist = new ArrayList<Orders>();
		orderRepository.findAll().forEach(orderlist::add);
		return orderlist;
	}
	
	//get order by orderid
	public Orders getOrderByid(int oid){
		Optional<Orders> ord = orderRepository.findById(oid);
		Orders ords = ord.get();
		return ords;
	}
	
	//get all orders of a customer
	public Collection<Orders> getOrdersofCustomer(String cid){
		Customers c = new Customers();
		c.setCustid(cid);
		return orderRepository.findByCustomers(c);
	}
	
	//get all orders of a product
	public Collection<Orders> getOrdersofProduct(int pid){
		Products p = new Products();
		p.setPno(pid);
		return orderRepository.findByProducts(p);
	}
	
	public Orders saveOrder(Orders orders){
		Counters counters = counterService.getOrderCounter();
		Optional<Products> products = productRepository.findById(orders.getProducts().getPno());
		Products ptds = products.get();
		if(ptds.getStock() > orders.getQty()){
			Optional<Customers> customers = customerRepository.findById(orders.getCustomers().getCustid());
			Customers ctr = customers.get();
			if(ctr.getCredit() > orders.getQty()*ptds.getPrice()){
				orders.setOrd_no(counterService.getNextValueofOrders(counters));
				orders.setOrd_date(LocalDate.now());
				orders.setCustomers(ctr);
				orders.setProducts(ptds);
				
				System.out.println(orders);
				orderRepository.save(orders);
				
				//to reduce stock of product
				ptds.setStock(ptds.getStock()-orders.getQty());
				productRepository.save(ptds);
				
				//to change customers credit
				ctr.setCredit(ctr.getCredit()-orders.getQty()*ptds.getPrice());
				customerRepository.save(ctr);
				
				//increament counter
				counterService.incrementCounter(counters);
			}else{
				System.out.println("Insufficient Balance.....");
			}
		}else{
			System.out.println("Insufficient Stock...");
		}
		return orders;
	}
	
}

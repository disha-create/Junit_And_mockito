package com.example.SalesApplication.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SalesApplication.model.Customers;
import com.example.SalesApplication.repository.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepository customerRepository;
	
	public List<Customers> getAllCustomers(){
		List<Customers> customerlist = new ArrayList<Customers>();
		customerRepository.findAll().forEach(customerlist::add);
		return customerlist;
	}
	
	@Transactional
	public void saveCustomer(Customers customers){
		customerRepository.save(customers);
	}
	
	public Customers getCustomerById(String cid){
		Optional<Customers> cust = customerRepository.findById(cid);
		Customers custd = cust.get();
		return custd;
	}
	
	@Transactional
	public void deleteCustomer(String id){
		customerRepository.deleteById(id);
	}

}

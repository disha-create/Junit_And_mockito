package com.example.SalesApplication.repository;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.example.SalesApplication.model.Invoices;

@Repository
public class InvoiceDAO {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public Collection<Invoices> getAllInvoices(){
		return jdbcTemplate.query("select ord_no, ord_date, cust_id, pno, qty, amt from invoices", 
				new BeanPropertyRowMapper<Invoices>(Invoices.class));
	}
	
	
	public Invoices getInvoiceById(int id){
		return jdbcTemplate.queryForObject("select ord_no, ord_date, cust_id, pno, qty, amt from invoices where ord_no=?", 
				new BeanPropertyRowMapper<Invoices>(Invoices.class), id);
	}
}

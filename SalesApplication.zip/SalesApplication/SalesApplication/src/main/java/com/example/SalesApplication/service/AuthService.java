package com.example.SalesApplication.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SalesApplication.Exception.CustomerNotFoundException;
import com.example.SalesApplication.Exception.LoginFailedException;
import com.example.SalesApplication.model.Customers;
import com.example.SalesApplication.model.Products;
import com.example.SalesApplication.repository.CustomerRepository;

@Service
public class AuthService {
	
	@Autowired
	private CustomerRepository customerRepository;
	
	public void Login(Customers userCustomer) throws CustomerNotFoundException{
		Customers cust = customerRepository.findByCustid(userCustomer.getCustid()); 
        if(cust != null){
            if(cust.getPwd().compareTo(userCustomer.getPwd()) == 0){
                
            }else{
            	throw new LoginFailedException("The username or password is incorrect..!");
            }
        }else{
        	throw new CustomerNotFoundException("Customer not found with id:- " + userCustomer.getCustid());
        }
    }
}

package com.citiustech.trading.testing;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.citiustech.trading.Portfolio;
import com.citiustech.trading.Stock;
import com.citiustech.trading.StockService;

public class PortfolioTest {

	Portfolio portfolio;
	StockService stockService; //interface so you cant creat object of it
	
	@Before
	public void setUp() {
		stockService = Mockito.mock(StockService.class);
		portfolio = new Portfolio(stockService);
	}
	
	@Test
	public void getMarketValueShouldReturnTotalPriceOfTheStocks() {
		List<Stock> stocks = new ArrayList<Stock>();
		Stock stock1 = new Stock(1001, "MSFT", 10);
		Stock stock2 = new Stock(1002, "ORCL", 20);
		
		stocks.add(stock1);
		stocks.add(stock2);
		
		portfolio.setStocks(stocks);
		
		Mockito.when(stockService.getStockPrice(stock1))
				.thenReturn(500);
		Mockito.when(stockService.getStockPrice(stock2))
		.thenReturn(700);
		
		int marketValue = portfolio.getMarketValue();
		
		assertEquals(19000, marketValue);
	}
}






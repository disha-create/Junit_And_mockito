package com.citiustech.trading.testing;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.MockitoRule;

import com.citiustech.trading.Portfolio;
import com.citiustech.trading.Stock;
import com.citiustech.trading.StockService;

@RunWith(MockitoJUnitRunner.class)
public class PortfolioTestWithAnnotation {

	@InjectMocks
	Portfolio portfolio;
	
	@Mock
	StockService stockService;
	
	@Test
	public void getMarketValueShouldReturnTotalPriceOfTheStocks() {
		List<Stock> stocks = new ArrayList<Stock>();
		Stock stock1 = new Stock(1001, "MSFT", 10);
		Stock stock2 = new Stock(1002, "ORCL", 20);
		
		stocks.add(stock1);
		stocks.add(stock2);
		
		portfolio.setStocks(stocks);
		
		Mockito.when(stockService.getStockPrice(stock1))
				.thenReturn(500);
		Mockito.when(stockService.getStockPrice(stock2))
		.thenReturn(700);
		
		int marketValue = portfolio.getMarketValue();
		
		assertEquals(19000, marketValue);
	}
}






package com.citiustech.trading;

import java.util.List;

public class Portfolio {

	private List<Stock> stocks;
	private StockService stockService;
	
	public Portfolio(StockService stockService) {
		this.stockService = stockService;
	}

	public List<Stock> getStocks() {
		return stocks;
	}

	public void setStocks(List<Stock> stocks) {
		this.stocks = stocks;
	}

	public StockService getStockService() {
		return stockService;
	}

	public void setStockService(StockService stockService) {
		this.stockService = stockService;
	}
	
	public int getMarketValue() {
		int total = 0;
		for (Stock stock : stocks) {
			total += stockService.getStockPrice(stock) * stock.getQuantity();
		}
		
		return total;
	}
}




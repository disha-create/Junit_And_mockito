package com.citiustech.trading;

public interface StockService {

	int getStockPrice(Stock stock);
}

package com.citiustech.DAO;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.citiustech.Model.Article;

@Repository
public interface ArticleRepository extends JpaRepository<Article, Integer> {

	Article findById(int id);
	Article findByTitle(String n);
}

package com.citiustech.TestAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.citiustech.DAO.ArticleRepository;
import com.citiustech.DAO.TagRepository;

@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan(basePackages = {"com.citiustech"})
@EnableJpaRepositories(basePackageClasses = {ArticleRepository.class, TagRepository.class})
@EntityScan("com.citiustech.Model")
public class TestAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestAssignmentApplication.class, args);
	}

}

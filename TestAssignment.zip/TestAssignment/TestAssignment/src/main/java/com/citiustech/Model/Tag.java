package com.citiustech.Model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Tag {

	private int id;
	private String tag;

	public Tag() {
		// TODO Auto-generated constructor stub
		this.id = (int)System.currentTimeMillis() % 100000;
	}
	
	@Id
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}
	
	private Article article;

	@ManyToOne(cascade= CascadeType.ALL)
	@JoinColumn(name="article_id")
	public Article getArticle() {
		return article;
	}

	public void setArticle(Article article) {
		this.article = article;
	}

	@Override
	public String toString() {
		return "Tag [id=" + id + ", tag=" + tag + ", article=" + article + "]";
	}
	
	
	
	
}

package com.citiustech.Exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

//	@ExceptionHandler(RuntimeException.class)
//	public ResponseEntity<?> handleRuntimeException(RuntimeException ex){
//		Map<String,String> error = new HashMap<>();
//		error.put("errorMessage", ex.getMessage());
//		return new ResponseEntity<>(error,HttpStatus.INTERNAL_SERVER_ERROR);
//	}
	
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<?> handleResourceNotFoundException(ResourceNotFoundException ex){
		Map<String,String> error = new HashMap<>();
		error.put("errorMessage", ex.getMessage());
		return new ResponseEntity<>(error,HttpStatus.INTERNAL_SERVER_ERROR);
	}
}

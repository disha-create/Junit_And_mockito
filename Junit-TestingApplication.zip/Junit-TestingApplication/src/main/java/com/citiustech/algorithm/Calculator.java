package com.citiustech.algorithm;

public class Calculator {
	
	
	/*public int multiply(int first,int second){
		return first*second;
	}*/

	public static int multiply(int first,int second){
		if(first >0 && second>0){
			return first*second;
		}
		return -1;
	}
	
}

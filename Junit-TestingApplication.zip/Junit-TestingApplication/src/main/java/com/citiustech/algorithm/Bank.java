package com.citiustech.algorithm;

public class Bank {
	
	public static String[] names ={"Jack","Jill","Jeff","jim"};
	public static double[] balance = {2000, 3000, 4000, 5000};
	
	
/*	public static double Search(String name){
		for(int i=0; i<names.length; i++){
			if(name.equals(names[i])){
				return balance[i];
			}
		}
		return -1;
	}*/
	
	public static double Search(String name){
		for (int i=0; i<names.length; i++){
			if(name.equals(names[i])){
				return balance[i];
			}
		}
		
		throw new NameNotFoundException();
	}

}

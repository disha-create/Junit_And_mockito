package com.citiustech.algorithm;

public class NameNotFoundException extends RuntimeException{

	
	String message;
	
	public void NameNotFoundException(String msg){
		message = msg;
	}
	
	public String getMessage(){
		return message;
	}
}

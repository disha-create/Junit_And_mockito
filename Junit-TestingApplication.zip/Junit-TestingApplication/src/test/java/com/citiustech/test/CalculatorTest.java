package com.citiustech.test;
//import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.citiustech.algorithm.Calculator;

public class CalculatorTest {

	
	Calculator calculator = new Calculator();
	
	@Test
	public void multiplyShouldmultiplyPositiveNumbers(){
		assertEquals(20,calculator.multiply(5, 4));
		
	}
	
	/*@Test
	public void bothNumbersShouldBePositiveNumbers(){
		assertEquals(40, calculator.multiply(8, -5));
	}*/
}

package com.citiustech.test;

import org.junit.Test;

import com.citiustech.algorithm.Bank;
import com.citiustech.algorithm.NameNotFoundException;

import static org.junit.Assert.assertEquals;

public class BankTest {
	
	Bank bank = new Bank();
	
	@Test
	public void searchShouldReturnBalanceForName(){
		assertEquals(2000, bank.Search("Jack"),0);
	}
	
	@Test(expected = NameNotFoundException.class)
	public void searchNameNotFoundException(){
		assertEquals(2000, bank.Search("Jackie"),0);
	}

}

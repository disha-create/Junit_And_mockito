$(document).ready(() => {
    $('#header').load('header.html');
    $.get("http://localhost:8080/products/all" , data=>{
        
        var container = ``;

        for(let i=0 ; i< data.length ; i++){
            // console.log(data[i]);
            container += `<div class="card grid-item col-md-6">
            <div class="card-body">
                <h5 class="card-title">Product No :- ${data[i].pno}</h5>
                <p class="card-text">Price :- ${data[i].price}</p>
                <p class="card-text">Available Stock :- ${data[i].stock}</p>
                <a class="btn btn-primary" href="./order.html?pno=${data[i].pno}">Order</a>
            </div>
         </div>`;
        }
        $('#content').html(container);
    });
})
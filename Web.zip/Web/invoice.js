$(document).ready(() => {
    $('#header').load('header.html');
    $.get("http://localhost:8080/invoices/all" , data=>{
        
        var container = ``;

        for(let i=0 ; i< data.length ; i++){
            
            container += `<div class="card grid-item col-md-6">
            <div class="card-body">
                <h5 class="card-title">Order No :- ${data[i].ord_no}</h5>
                <p class="card-text">Order Date :- ${data[i].ord_date}</p>
                <p class="card-text">Cust id :- ${data[i].cust_id}</p>
                <h5 class="card-title">Product No :- ${data[i].pno}</h5>
                <p class="card-text">Quantity :- ${data[i].qty}</p>
                <p class="card-text">Amount :- ${data[i].amt}</p>
            </div>
         </div>`;
        }
        $('#content').html(container);
    });
})
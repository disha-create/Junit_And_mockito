$(document).ready(() => {

    $('#header').load('./header.html');

    if(window.localStorage.getItem('CustomerID') == null){
        window.location.href = "./login.html";
    }

    $.urlParam = function (name) {
        var results = new RegExp('[\?&]' + name + '=([^&#]*)')
                          .exec(window.location.search);
        return (results !== null) ? results[1] || 0 : false;
    }

    
    $.getProduct = function(pno){
        var container = '';
        $.get("http://localhost:8080/product/"+pno)
        .done((data) => {
            var leftMessage = "";
            if(data.stock > 1){
                leftMessage = data.stock + " items left....!";
            }else if(data.stock == 1){
                leftMessage = data.stock + " item left....!";
            }else if(data.stock < 1){
                $('#buyBtn').attr("disabled",true)
                leftMessage = "Item not in stock";
            }
            container += `<div class="card grid-item">
            <div class="card-body">
                <p class="card-text" style="font-size:18px">Price :- ${data.price}</p>
                <div style="text-align:right;color:green">${leftMessage}</div>
            </div>
         </div>`;
         $('#divLeft').html(container);
        })
    }

    if($.urlParam('pno') == false){
        window.location.href="http://127.0.0.1:5500/main.html";
    }else{
        $.getProduct($.urlParam('pno'));
    }

    $('#buyBtn').click(() => {
        let qty = $("#qty").val();
        if(qty >= 0 &  qty != ""){
            
        }else{
            alert("Please Enter Correct Quantity");
        }
    })
})
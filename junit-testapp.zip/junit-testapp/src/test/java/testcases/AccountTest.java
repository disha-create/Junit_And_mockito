package testcases;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import bank.Account;
import bank.NameNotFoundException;

public class AccountTest {

	@Test
	public void searchShouldReturnBalanceForAName() {
		assertEquals(2000.00, Account.search("Jack"), 0);
	}
	
	@Test(expected = NameNotFoundException.class)
	public void searchShouldThrowNameNotFoundException() {
		assertEquals(2000.00, Account.search("Jackie"), 0);		
	}
}





package testcases;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;


@RunWith(Parameterized.class)
public class SavingsAccountTest {


	   @Parameter(0)
	    public int id;
	    
	    @Parameter(1)
	    public double balance;
	    
	    @Parameter(2)
	    public int result;
	    
	    @Parameters
	    public static List inputData(){
	        return Arrays.asList(new Object[][]{{1,1000,1000},
	            {2,4000,4000},{3,5000,5000},{4,100,100}});
	    }
	    
	    @Before
	    public void beforeEachTest(){
	    	SavingsAccount ca = new SavingsAccount();
	    	ca.setBalance = 10000;
	    
	    }
	    
	    
	// check if id is exist or not
	    @Test
	    public void accountIdShouldExistsOrNotTestCase(){
	        assertEquals(1, SavingAccountTest.saving());
	    }
	}
	    
//	    get balance By id
	    @Test
	    public void checkForBalance(){
	        assertEquals(result, SavingAccount.saving(id,balance));
	    }

//      check if amount deposited successfully or not
	    @Test
	    public void isAmountDepositedTestCase(){
	    	account.deposite(500);
	    	assertEquals(10500,account.getBalance());
	    }
	    	
//      check if withdrawal happens successfully
	    @Test
	    public void withdrawMoneyTest() {
	    account.withdraw(500);
	    assertEquals(9500.0,account.getBalance(),"Withdraw Test");
	    }



}

package testcases;

import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;



@RunWith(Parameterized.class)
public class CurrentAccountTest {
	
	

	   @Parameter(0)
	    public int id;
	    
	    @Parameter(1)
	    public double balance;
	    
	    @Parameter(2)
	    public int result;
	    
	    @Parameters
	    public static List inputData(){
	        return Arrays.asList(new Object[][]{{1,1000,1000},
	            {2,4000,4000},{3,5000,5000},{4,100,100}});
	    }
	    
	    
	    @Before
	    public void beforeEachTest(){
	    	CurrentAccount ca = new CurrentAccount();
	    	ca.setBalance = 0;
	    
	    }
	    s
	// check if id is exist or not
	    @Test
	    public void accountIdExistsOrNotTestCase(){
	        assertEquals(1, CurrentAccountTest.saving());
	    }
	}
	    
//	    get balance By id
	    @Test
	    public void checkForBalance(){
	        assertEquals(result, CurrentAccount.saving(id,balance));
	    }

//check if amount deposited successfully or not
	    @Test
	    public void isAmountDepositedTestCase(){
	    	account.deposite(500);
	    	assertEquals(500,account.getBalance());
	    }
	    	
	    //check if withdrawal happens successfully
	    @Test
	    public void withdrawMoneyTest() {
	    account.withdraw(500);
	    assertEquals(False,account.getBalance(),"Withdraw Test");
	    }
	    
	    //check for user validation for withdraw
	    @Test
	    public void userValidationByAccountNumber(){
	    	account.getDetails(456738291022);
	    	assertEquals("Jack",CurrentAccount.searchForUserValidation());
	    	
	    }

}

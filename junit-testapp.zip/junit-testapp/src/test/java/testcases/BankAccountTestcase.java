package testcases;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

public class BankAccountTestcase {
	
	@RunWith(Parameterized.class)
	public class SavingAccountTest {



	   @Parameter(0)
	    public int id;
	    
	    @Parameter(1)
	    public double balance;
	    
	    @Parameter(2)
	    public int result;
	    
	    @Parameters
	    public static List inputData(){
	        return Arrays.asList(new Object[][]{{1,1000,1000},
	            {2,4000,4000},{3,5000,5000},{4,100,100}});
	    }
	    
//	    get the balance according to id
	    @Test
	    public void getTheBalance(){
	        assertEquals(result, SavingAccount.saving(id,balance));
	    }



	// check if id is exist or not
	    
	    public void accountIdExistsOrNot(){
	        assertEquals(1, SavingAccountTest.saving());
	    }
	}
	
	/*
	 * Check the accounting field by entering an invalid account number.
	 * Verify the amount and other details on the verification pag
	 * */
	/*




}

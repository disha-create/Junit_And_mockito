package testcases;

import static org.junit.Assert.assertEquals;


import org.junit.Test;

import algorithm.Calculator;
import bank.Account;



/*
 * Both numbers should be positive
 * Both numbers should not be zero
 * ...
 */

public class CalculatorTest {

	@Test
	public void additionShouldAddPositiveNumbers(){
		assertEquals(-1, Calculator.addition(-10, -20));		
	}

}



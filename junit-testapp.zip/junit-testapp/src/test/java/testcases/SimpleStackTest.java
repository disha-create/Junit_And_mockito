package testcases;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import customcollection.SimpleStack;


public class SimpleStackTest {
	
	SimpleStack<String> strStack;
	
	@Before
	public void codeBeforeTestCase() {
		strStack = new SimpleStack<String>();
	}

	
	  @Test public void simpleStackShouldAddElementToTheStack() {
		  	strStack.push("Jack"); 
	}
	 /* 
	 * @Test public void simpleStackShouldReturnTopOfTheStackElement() {
	 * strStack.push("Jack"); assertEquals("Jack", strStack.peek()); }
	 * 
	 * @Test public void pushShouldIncrementTheSizeOfTheStack() {
	 * strStack.push("Jack"); strStack.push("Jill"); assertEquals(2,
	 * strStack.size()); }
	 */	
	@Test
	public void popShouldDecrementTheSizeOfTheStack() {
		strStack.push("Jill");
		strStack.push("John");
		strStack.pop();
		assertEquals(1, strStack.size());
	}
}





package customcollection;

public class SimpleStack <V>{
	
	Node top;
	int size;

	//Stack has-a Node (Inner class)
	//SimpleStack<String> names = new SimpleStack<>();
	class Node{
		V data;
		Node below;
		
		public Node(V data) {
			// TODO Auto-generated constructor stub
			this.data = data;
			below = top;
			size++;
		}
	}
	
	public void push(V value) {
		top = new Node(value);
	}
	
	public V pop() {
		V data = top.data;
		top = top.below;
		size--;
		return data;
	}
	
	public V peek() {
		return top.data;
	}

	public int size() {
		// TODO Auto-generated method stub
		return size;
	}
}

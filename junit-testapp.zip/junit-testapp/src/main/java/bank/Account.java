package bank;



public class Account {

	/*private static String[] names = {"Jack", "Jill", "John", "Jeff"};
	private static double[] balances = {2000, 4000, 5000, 7000};
	
	
	public static double search(String name) {
		
		for(int i = 0; i < names.length; ++i) {
			if(name.equals(names[i]))
				return balances[i];
		}
		
		//return -1;
		throw new NameNotFoundException();
	}*/
}

















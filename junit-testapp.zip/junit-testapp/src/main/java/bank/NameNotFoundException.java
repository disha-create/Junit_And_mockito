package bank;

public class NameNotFoundException extends RuntimeException{
	
	/*
	 * private String message;
	 * 
	 * public NameNotFoundException(String msg) { message = msg; }
	 * 
	 * public String getMessage() { return message; }
	 */
}

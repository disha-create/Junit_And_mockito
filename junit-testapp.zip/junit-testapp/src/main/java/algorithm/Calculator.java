package algorithm;

public class Calculator {

	public static int addition(int first, int second) {
		// TODO Auto-generated method stub
		if(first > 0 && second > 0)
			return first + second;
		return -1;
	}

}

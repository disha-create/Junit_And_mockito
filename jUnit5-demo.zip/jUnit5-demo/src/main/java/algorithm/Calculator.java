package algorithm;

public class Calculator {
	
	
	public static int addition(int first, int second){
		if(first > 0 && second > 0)
			return first + second;
		return -1;
	}
	
	
	public static int substraction(int first, int second){
		if(first > 0 && second > 0)
			return first - second;
		return -1;
	}


}

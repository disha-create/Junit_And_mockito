package testCases;


import org.junit.jupiter.api.Test;

import algorithm.Calculator;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;


public class CalculatorTest {
	
	@BeforeAll
	public static void setup(){
		System.out.println("@BeforeAll executed");
	}
	
	Calculator calculator=null;
	
	@BeforeEach
	public void before(){
		System.out.println("@BeforeAll executed");
		calculator = new Calculator();
	}
	
	@Test
	public void additionShouldAddPositiveNumbers(){
		assertEquals(20, calculator.addition(10, 10));
	}
	
	@Test
	public void substractionShouldAddPositiveNumbers(){
		assertEquals(20, calculator.addition(30, 10));
	}
	
	@Test
	public void additionShouldAddPositiveNumbersIfNotThenThrowsException(){
		assertEquals(35, calculator.addition(15, 20));
	}
	
	
	@AfterEach
	void tearThis(){
		System.out.println("@AfterEach executed");
	}

	@AfterAll
	static void tear(){
		System.out.println("@AfterAll executed");
	}

}

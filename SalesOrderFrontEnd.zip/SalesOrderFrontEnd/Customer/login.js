$(document).ready(()=>{    
    
    $('#submit').click(()=>{
        var username = $('#username').val();
        var password = $('#password').val();
        console.log("Hello");
        if(username === '' || password=== ''){
            alert("Please enter username and password");
        }else{
            var data = {
                custid:username,
                pwd:password
            }
            console.log(data);
            var dataObject = JSON.stringify(data);
            console.log(dataObject);
            $.post({
                url:'http://localhost:8080/auth/login',
                data:dataObject,
                contentType:'application/json'
            }).done(data => {
                window.localStorage.setItem("CustomerID", data.CustomerId);
                window.location.href = "main.html";
            }).fail(data => {
                console.log(data);
                alert(data.responseJSON.errorMessage);
            })
        }
    })
})
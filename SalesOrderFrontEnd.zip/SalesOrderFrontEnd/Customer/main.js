$(document).ready(() => {
    $('#header').load('header.html');
    // if(window.localStorage.getItem('AdminID') == null){
    //     window.location.href = "./login.html";
    // }
    $.get("http://localhost:8080/products/all", data => {
        var container = ``;
        for (let i = 0; i < data.length; i++) {
            container += `<tr>
            <td> ${data[i].pno}
            </td>
            <td> ${data[i].stock}
            </td>
            <td> ${data[i].price}
            </td>
            </tr> `;  
            
        }
        $('#tt').html(container);
    });

    // $.get("http://localhost:8080/customers/all", data => {
    //     var container1 = ``;
    //     for (let i = 0; i < data.length; i++) {
    //         container1 += `
    //         <div class="col-lg-3 col-md-4 mt-4">
    //             <div class="icon-box">
    //                 <i class="ri-fingerprint-line" style="color: #29cc61;"></i>
    //                 <h3>Customer:- <a href="./managecustomer.html?custid=${data[i].custid}">${data[i].custid}</a></h3>
    //             </div>
    //         </div>`;
    //     }
    //     $('#cust').html(container1);
    // });
})
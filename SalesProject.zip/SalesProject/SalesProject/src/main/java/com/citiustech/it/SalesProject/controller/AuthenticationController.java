package com.citiustech.it.SalesProject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.citiustech.it.SalesProject.model.Customers;
import com.citiustech.it.SalesProject.repository.CustomerRepository;

@RestController
@RequestMapping("/login")
@CrossOrigin(origins="http://127.0.0.1:5500")
public class AuthenticationController {

	@Autowired
	private Customers customer;
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@PostMapping
	public String checkValue(String custId, String password){
		Customers dbCustomer = customerRepository.getById(custId);
		
		System.out.println(customerRepository.getById(custId));
		
		if (dbCustomer != null){
			if (dbCustomer.getPwd().equals(password)){
				
			return dbCustomer.getCustId();
				
			}
			return "Login failed! Please enter valid password.";
		}
		
		return "Login failed! Please enter valid username.";
	}
	
}

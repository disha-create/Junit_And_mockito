package com.citiustech.it.SalesProject.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.citiustech.it.SalesProject.model.Invoice;
import com.citiustech.it.SalesProject.service.InvoiceService;

@RestController
@RequestMapping("/invoice")
@CrossOrigin(origins="http://127.0.0.1:5500")
public class InvoiceController {

	@Autowired
    private InvoiceService invoiceService;
    
    @GetMapping
    public Collection<Invoice> getAllInvoices(){
        return invoiceService.getAllInvoices();
    }
	
}

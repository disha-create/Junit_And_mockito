package com.citiustech.it.SalesProject.model;


import java.time.LocalDate;

import javax.xml.crypto.Data;

public class Invoice {
	
	private int orderNo;
	private LocalDate orderDate;
	private String cust_id;
	private int productNo;
	private int quantity;
	private double price;
	
	public Invoice() {

	}
	
	public Invoice(int orderNo, LocalDate orderDate, String cust_id, int productNo, int quantity, double price) {
		this.orderNo = orderNo;
		this.orderDate = orderDate;
		this.cust_id = cust_id;
		this.productNo = productNo;
		this.quantity = quantity;
		this.price = price;
	}

	public int getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}

	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

	public String getCust_id() {
		return cust_id;
	}

	public void setCust_id(String cust_id) {
		this.cust_id = cust_id;
	}

	public int getProductNo() {
		return productNo;
	}

	public void setProductNo(int productNo) {
		this.productNo = productNo;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Invoice [orderNo=" + orderNo + ", orderDate=" + orderDate + ", cust_id=" + cust_id + ", productNo="
				+ productNo + ", quantity=" + quantity + ", price=" + price + "]";
	}
	
	
}

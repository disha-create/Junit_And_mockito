package com.citiustech.it.SalesProject.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.citiustech.it.SalesProject.model.Invoice;
import com.citiustech.it.SalesProject.repository.InvoiceDAO;

@Service
public class InvoiceService {

	 	@Autowired
	    private InvoiceDAO invoiceDAO;
	    
	    public Collection<Invoice> getAllInvoices(){
	        return invoiceDAO.getAllInvoices();
	    }
	
}
